"""
TrainBot - AI Training Course Generator
Dark Theme UI - Inspired by Zavvy Dashboard

Built for MCP 1st Birthday Hackathon
"""

import gradio as gr
import os
import re
import tempfile
from dotenv import load_dotenv
import google.generativeai as genai
from document_processor import process_document, answer_question_with_gemini
from course_generator import generate_course_with_gemini
from voice_processor import transcribe_audio, text_to_speech, save_audio
from fpdf import FPDF

load_dotenv()
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

uploaded_docs = []

# ============================================
# PDF UTILITIES
# ============================================

def strip_emojis(text):
    emoji_pattern = re.compile("["
        "\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF"
        "\U0001F1E0-\U0001F1FF\U00002702-\U000027B0\U000024C2-\U0001F251"
        "\u2640-\u2642\u2600-\u2B55\u200d\u23cf\u23e9\u231a\ufe0f\u3030"
        "⚡📗📙📕📚❓✨🎓📁🔍✓⚠️❌🎤📥📊📄📝🎬▶️🔗💡🧠📋✅●○"
        "]+", flags=re.UNICODE)
    return emoji_pattern.sub('', text)

def export_to_pdf(content, title="Document"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_left_margin(15)
    pdf.set_right_margin(15)
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_x(15)
    pdf.multi_cell(180, 8, strip_emojis(title)[:60], align="C")
    pdf.ln(5)
    for line in content.split('\n'):
        orig = line
        line = strip_emojis(line).strip()
        if not line:
            pdf.ln(2)
            continue
        clean = line.replace('**','').replace('*','').replace('`','').replace('#','').strip()
        if not clean:
            continue
        try:
            pdf.set_x(15)
            if orig.strip().startswith('# '):
                pdf.ln(2)
                pdf.set_font("Helvetica", "B", 13)
                pdf.multi_cell(180, 6, orig.strip()[2:].replace('*',''))
            elif orig.strip().startswith('## '):
                pdf.ln(2)
                pdf.set_font("Helvetica", "B", 12)
                pdf.multi_cell(180, 5, orig.strip()[3:].replace('*',''))
            elif orig.strip().startswith('### '):
                pdf.set_font("Helvetica", "B", 11)
                pdf.multi_cell(180, 5, orig.strip()[4:].replace('*',''))
            elif orig.strip().startswith('- '):
                pdf.set_font("Helvetica", "", 10)
                pdf.multi_cell(180, 5, "  • " + orig.strip()[2:].replace('*',''))
            else:
                pdf.set_font("Helvetica", "", 10)
                pdf.multi_cell(180, 5, clean)
        except:
            continue
    safe = "".join(c for c in title if c.isalnum() or c in ' -_').replace(' ','_')[:40] or "doc"
    path = os.path.join(tempfile.gettempdir(), f"{safe}.pdf")
    if os.path.exists(path):
        os.remove(path)
    pdf.output(path)
    return path

def export_flashcards_pdf(content, title):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    cards = []
    front, back = "", ""
    for line in content.split('\n'):
        line = strip_emojis(line).strip()
        if line.startswith(('Front:','Q:','Question:')):
            if front and back:
                cards.append((front, back))
            front = line.split(':',1)[1].strip() if ':' in line else line
            back = ""
        elif line.startswith(('Back:','A:','Answer:')):
            back = line.split(':',1)[1].strip() if ':' in line else line
    if front and back:
        cards.append((front, back))
    if not cards:
        pdf.add_page()
        pdf.set_font("Helvetica", "", 10)
        for line in content.split('\n')[:50]:
            line = strip_emojis(line).strip()
            if line:
                try:
                    pdf.set_x(15)
                    pdf.multi_cell(180, 5, line.replace('*','')[:150])
                except:
                    pass
    else:
        for i, (f, b) in enumerate(cards, 1):
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 12)
            pdf.cell(180, 10, f"Card {i}/{len(cards)}", align="C", new_x="LMARGIN", new_y="NEXT")
            pdf.ln(8)
            pdf.set_fill_color(245, 245, 245)
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(180, 8, "QUESTION", align="C", fill=True, new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)
            pdf.set_font("Helvetica", "", 11)
            pdf.set_x(15)
            pdf.multi_cell(180, 6, f.replace('*',''), align="C")
            pdf.ln(10)
            pdf.set_fill_color(230, 250, 230)
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(180, 8, "ANSWER", align="C", fill=True, new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)
            pdf.set_font("Helvetica", "", 11)
            pdf.set_x(15)
            pdf.multi_cell(180, 6, b.replace('*',''), align="C")
    safe = "".join(c for c in title if c.isalnum() or c in ' -_').replace(' ','_')[:40] or "cards"
    path = os.path.join(tempfile.gettempdir(), f"{safe}.pdf")
    if os.path.exists(path):
        os.remove(path)
    pdf.output(path)
    return path


# ============================================
# CORE FUNCTIONS
# ============================================

def get_sources_list():
    if not uploaded_docs:
        return "No files uploaded yet"
    return "\n".join([f"• {d['filename']}" for d in uploaded_docs])

def get_sources_count():
    n = len(uploaded_docs)
    return f"{n} file(s)" if n > 0 else "No files"

def get_file_choices():
    return [d['filename'] for d in uploaded_docs] if uploaded_docs else []

def get_selected():
    return [d for d in uploaded_docs if d.get('selected', True)]

def upload_file(file):
    if not file:
        return get_sources_list(), gr.update(choices=get_file_choices(), value=get_file_choices()), "Ready", None, get_sources_count()
    try:
        doc = process_document(file.name)
        if 'error' in doc['metadata']:
            return get_sources_list(), gr.update(), "Error processing", None, get_sources_count()
        if doc['filename'] in [d['filename'] for d in uploaded_docs]:
            return get_sources_list(), gr.update(), "Already loaded", None, get_sources_count()
        doc['selected'] = True
        uploaded_docs.append(doc)
        choices = get_file_choices()
        return get_sources_list(), gr.update(choices=choices, value=choices), f"✓ Added", None, get_sources_count()
    except Exception as e:
        return get_sources_list(), gr.update(), f"Error", None, get_sources_count()

def add_youtube(url):
    if not url or ('youtube' not in url and 'youtu.be' not in url):
        return get_sources_list(), gr.update(), "Invalid URL", get_sources_count()
    try:
        vid = url.split('v=')[1].split('&')[0] if 'v=' in url else url.split('/')[-1].split('?')[0]
        doc = {'filename': f"YT_{vid[:8]}", 'content': f"YouTube: {url}", 'metadata': {}, 'selected': True}
        uploaded_docs.append(doc)
        choices = get_file_choices()
        return get_sources_list(), gr.update(choices=choices, value=choices), "✓ Added", get_sources_count()
    except:
        return get_sources_list(), gr.update(), "Error", get_sources_count()

def update_selection(selected):
    for d in uploaded_docs:
        d['selected'] = d['filename'] in selected
    return get_sources_list()

def delete_file(files_to_keep):
    global uploaded_docs
    if files_to_keep:
        uploaded_docs = [d for d in uploaded_docs if d['filename'] in files_to_keep]
    else:
        uploaded_docs = []
    return get_sources_list(), gr.update(choices=get_file_choices(), value=get_file_choices()), get_sources_count()

def chat_fn(message, history):
    if not message:
        return history, ""
    sel = get_selected()
    if not sel:
        return history + [[message, "Please upload documents first."]], ""
    try:
        response = answer_question_with_gemini(message, sel)
        return history + [[message, response]], ""
    except Exception as e:
        return history + [[message, f"Error: {e}"]], ""

def voice_fn(audio):
    if not audio:
        return None, "Record a question first"
    sel = get_selected()
    if not sel:
        return None, "Upload documents first"
    try:
        question = transcribe_audio(audio)
        answer = answer_question_with_gemini(question, sel)
        audio_data = text_to_speech(answer[:500])
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
        save_audio(audio_data, tmp.name)
        return tmp.name, f"Q: {question}\n\nA: {answer}"
    except Exception as e:
        return None, f"Error: {e}"

def summary_fn(summary_type):
    sel = get_selected()
    if not sel:
        return "Upload documents first"
    try:
        content = "\n\n".join([f"{d['filename']}:\n{d.get('content','')[:4000]}" for d in sel])
        model = genai.GenerativeModel('gemini-2.0-flash')
        prompts = {
            "Executive": f"Write a 200-word executive summary:\n\n{content}",
            "Detailed": f"Write a detailed summary:\n\n{content}",
            "Key Points": f"Extract 5-7 key points:\n\n{content}"
        }
        return model.generate_content(prompts.get(summary_type, prompts["Executive"])).text
    except Exception as e:
        return f"Error: {e}"

def generate_content(mode, title, topic, c_modules, c_level, m_style, m_modules, q_level, q_num, f_level, f_num, language):
    sel = get_selected()
    if not sel:
        return "Upload documents first", None, gr.update(visible=False)
    try:
        lang_note = f"\n\nGenerate in {language}." if language != "English" else ""
        sources = ", ".join([d['filename'] for d in sel])
        combined = "\n".join([d.get('content','')[:3000] for d in sel])
        model = genai.GenerativeModel('gemini-2.0-flash')
        
        if mode == "Full Course":
            content = generate_course_with_gemini(topic + lang_note, c_modules, c_level, sel)
            doc_title = title
        elif mode == "Micro Course":
            prompt = f"Create a {m_style} micro-course with {m_modules} modules.{lang_note}\n\n{combined}\n\nTopic: {topic}"
            content = model.generate_content(prompt).text
            doc_title = f"{title} (Micro)"
        elif mode == "Quiz":
            prompt = f"Create {q_num} {q_level} multiple choice questions.{lang_note}\n\n{combined}"
            content = model.generate_content(prompt).text
            doc_title = f"{title} - Quiz"
        elif mode == "Flashcards":
            prompt = f"Create {f_num} {f_level} flashcards.{lang_note}\n\n{combined}\n\nFormat: Front: [Q] Back: [A]"
            content = model.generate_content(prompt).text
            doc_title = f"{title} - Flashcards"
        else:
            return "Select a type", None, gr.update(visible=False)
        
        full = f"# {doc_title}\n\n{content}\n\n---\nSources: {sources}"
        pdf = export_flashcards_pdf(content, doc_title) if mode == "Flashcards" else export_to_pdf(full, doc_title)
        return full, pdf, gr.update(visible=True)
    except Exception as e:
        return f"Error: {e}", None, gr.update(visible=False)


# ============================================
# DARK THEME CSS - Zavvy Inspired
# ============================================

css = """
/* Google Font Import */
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap');

/* ══════════════════════════════════════════════════════════
   TRAINBOT DARK THEME
   Colors from Zavvy Dashboard:
   - Background: #1D1B21 (dark purple-black)
   - Sidebar: #2A2831 (slightly lighter)
   - Cards: #2A2831
   - Accent Purple: #9A76D9 / #8B5FC6
   - Accent Teal: #5EEAD4
   - Text: #FFFFFF / #E5E5E5
   ══════════════════════════════════════════════════════════ */

/* Reset & Base */
* { box-sizing: border-box; }
footer { display: none !important; }

html, body, .gradio-container {
    margin: 0 !important;
    padding: 0 !important;
    background: #1D1B21 !important;
    min-height: 100vh !important;
    font-family: 'Montserrat', -apple-system, BlinkMacSystemFont, sans-serif !important;
}

.gradio-container {
    max-width: 100% !important;
    width: 100% !important;
}

/* Main Layout */
.main-row {
    display: flex !important;
    min-height: 100vh !important;
    gap: 0 !important;
}

/* ===== SIDEBAR ===== */
.sidebar {
    background: #2A2831 !important;
    border-radius: 24px !important;
    margin: 16px !important;
    padding: 24px 20px !important;
    min-width: 240px !important;
    max-width: 260px !important;
    height: calc(100vh - 32px) !important;
    overflow-y: auto !important;
}

.sidebar-title {
    color: #FFFFFF !important;
    font-size: 1.4rem !important;
    font-weight: 700 !important;
    margin-bottom: 8px !important;
    letter-spacing: -0.02em !important;
}

.sidebar-subtitle {
    color: #71717A !important;
    font-size: 0.8rem !important;
    margin-bottom: 24px !important;
}

/* Sidebar Nav Items */
.nav-item {
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    padding: 12px 16px !important;
    border-radius: 12px !important;
    color: #E5E5E5 !important;
    font-size: 0.9rem !important;
    cursor: pointer !important;
    transition: all 0.2s ease !important;
    margin-bottom: 4px !important;
}

.nav-item:hover {
    background: rgba(154, 96, 249, 0.1) !important;
    color: #FFFFFF !important;
}

.nav-item.active {
    background: rgba(154, 96, 249, 0.15) !important;
    color: #FFFFFF !important;
}

.nav-icon {
    width: 20px !important;
    height: 20px !important;
    opacity: 0.7 !important;
}

/* ===== MAIN CONTENT ===== */
.main-content {
    flex: 1 !important;
    padding: 16px 24px 16px 8px !important;
    overflow-y: auto !important;
    height: 100vh !important;
}

.content-card {
    background: #2A2831 !important;
    border-radius: 20px !important;
    padding: 28px !important;
    margin-bottom: 16px !important;
}

/* ===== TYPOGRAPHY ===== */
h1, h2, h3, .gr-markdown h1, .gr-markdown h2, .gr-markdown h3 {
    color: #FFFFFF !important;
    font-weight: 700 !important;
}

h1, .gr-markdown h1 {
    font-size: 1.75rem !important;
    margin-bottom: 8px !important;
}

h2, .gr-markdown h2 {
    font-size: 1.1rem !important;
    margin-bottom: 16px !important;
}

p, span, label, .gr-markdown p {
    color: #E5E5E5 !important;
    font-size: 0.9rem !important;
}

/* ===== TABS ===== */
.tabs, .gr-tabs {
    background: transparent !important;
    border: none !important;
}

.tab-nav {
    background: #1D1B21 !important;
    border: none !important;
    border-radius: 16px !important;
    padding: 6px !important;
    gap: 4px !important;
    margin-bottom: 20px !important;
}

.tab-nav button {
    background: transparent !important;
    border: none !important;
    border-radius: 12px !important;
    padding: 12px 20px !important;
    color: #71717A !important;
    font-weight: 500 !important;
    font-size: 0.9rem !important;
    transition: all 0.2s ease !important;
}

.tab-nav button:hover {
    color: #E5E5E5 !important;
}

.tab-nav button.selected {
    background: #9A76D9 !important;
    color: #FFFFFF !important;
}

/* Inner tabs (Chat/Voice/Summary) */
.inner-tabs .tab-nav {
    background: rgba(255,255,255,0.05) !important;
    padding: 4px !important;
    border-radius: 10px !important;
}

.inner-tabs .tab-nav button {
    padding: 8px 16px !important;
    font-size: 0.85rem !important;
}

.inner-tabs .tab-nav button.selected {
    background: #9A76D9 !important;
}

/* ===== INPUTS ===== */
input, textarea, .gr-textbox input, .gr-textbox textarea {
    background: #1D1B21 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 12px !important;
    color: #FFFFFF !important;
    padding: 12px 16px !important;
    font-size: 0.9rem !important;
    transition: all 0.2s ease !important;
}

input:focus, textarea:focus {
    border-color: #9A76D9 !important;
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(154, 96, 249, 0.2) !important;
}

input::placeholder, textarea::placeholder {
    color: #52525B !important;
}

/* Labels */
label, .gr-input-label, .label-wrap {
    color: #E5E5E5 !important;
    font-size: 0.85rem !important;
    font-weight: 500 !important;
    margin-bottom: 6px !important;
}

/* ===== DROPDOWNS ===== */
.gr-dropdown select,
.gr-dropdown input {
    background: #1D1B21 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 12px !important;
    color: #FFFFFF !important;
    padding: 12px 16px !important;
}

/* Dropdown list - force open downward */
.gr-dropdown ul,
.gr-dropdown [role="listbox"],
div[data-testid="dropdown"] ul {
    background: #2A2831 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 12px !important;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4) !important;
    position: absolute !important;
    top: 100% !important;
    bottom: auto !important;
    z-index: 9999 !important;
    margin-top: 4px !important;
}

.gr-dropdown li,
.gr-dropdown [role="option"] {
    color: #E5E5E5 !important;
    padding: 10px 16px !important;
}

.gr-dropdown li:hover,
.gr-dropdown [role="option"]:hover {
    background: rgba(154, 96, 249, 0.15) !important;
    color: #FFFFFF !important;
}

/* ===== BUTTONS ===== */
button, .gr-button {
    font-family: 'Montserrat', sans-serif !important;
    font-weight: 600 !important;
    border-radius: 12px !important;
    padding: 12px 24px !important;
    transition: all 0.2s ease !important;
    cursor: pointer !important;
}

/* Primary Button - Purple Gradient */
.gr-button-primary, button.primary {
    background: linear-gradient(135deg, #9A76D9 0%, #8B5FC6 100%) !important;
    color: #FFFFFF !important;
    border: none !important;
    box-shadow: 0 4px 16px rgba(154, 96, 249, 0.3) !important;
}

.gr-button-primary:hover, button.primary:hover {
    background: linear-gradient(135deg, #A875FA 0%, #8B5CF6 100%) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px rgba(154, 96, 249, 0.4) !important;
}

/* Secondary Button */
.gr-button-secondary, button.secondary {
    background: transparent !important;
    color: #E5E5E5 !important;
    border: 1px solid #3F3D47 !important;
}

.gr-button-secondary:hover, button.secondary:hover {
    background: rgba(255,255,255,0.05) !important;
    color: #FFFFFF !important;
    border-color: #52525B !important;
}

/* ===== FILE UPLOAD ===== */
.gr-file {
    background: #1D1B21 !important;
    border: 2px dashed #3F3D47 !important;
    border-radius: 16px !important;
    min-height: 120px !important;
    transition: all 0.3s ease !important;
}

.gr-file:hover {
    border-color: #9A76D9 !important;
    background: rgba(154, 96, 249, 0.05) !important;
}

.gr-file svg {
    color: #71717A !important;
}

/* ===== CHATBOT ===== */
.gr-chatbot {
    background: #1D1B21 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 16px !important;
    min-height: 240px !important;
}

.gr-chatbot .message {
    border-radius: 12px !important;
    padding: 12px 16px !important;
}

.gr-chatbot .message.user {
    background: linear-gradient(135deg, #9A76D9 0%, #8B5FC6 100%) !important;
    color: #FFFFFF !important;
}

.gr-chatbot .message.bot {
    background: #3F3D47 !important;
    color: #FFFFFF !important;
}

/* ===== AUDIO ===== */
.gr-audio {
    background: #1D1B21 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 12px !important;
}

/* ===== CHECKBOX GROUP ===== */
.gr-checkbox-group {
    background: transparent !important;
}

.gr-checkbox-group label {
    background: rgba(154, 96, 249, 0.15) !important;
    color: #FFFFFF !important;
    padding: 8px 14px !important;
    border-radius: 10px !important;
    font-size: 0.85rem !important;
    border: 1px solid rgba(154, 96, 249, 0.3) !important;
}

.gr-checkbox-group input[type="checkbox"] {
    display: none !important;
}

/* ===== SOURCE BOX ===== */
.source-box textarea {
    background: #1D1B21 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 12px !important;
    color: #E5E5E5 !important;
    font-size: 0.85rem !important;
}

/* ===== STATUS ===== */
.status-box input {
    background: rgba(154, 96, 249, 0.1) !important;
    border: 1px solid rgba(154, 96, 249, 0.2) !important;
    color: #E5E5E5 !important;
    font-size: 0.8rem !important;
}

/* ===== MODAL ===== */
#output-modal {
    position: fixed !important;
    top: 50% !important;
    left: 50% !important;
    transform: translate(-50%, -50%) !important;
    background: #2A2831 !important;
    border: 1px solid #3F3D47 !important;
    border-radius: 24px !important;
    box-shadow: 0 32px 64px rgba(0,0,0,0.5) !important;
    z-index: 10000 !important;
    width: 90% !important;
    max-width: 700px !important;
    max-height: 85vh !important;
    overflow: hidden !important;
    padding: 28px !important;
}

#output-modal h3 {
    color: #5EEAD4 !important;
    font-size: 1.1rem !important;
}

#output-modal textarea {
    background: #1D1B21 !important;
    color: #E4E4E7 !important;
    border: 1px solid #3F3D47 !important;
    min-height: 300px !important;
}

#output-modal .gr-row {
    display: flex !important;
    gap: 12px !important;
    justify-content: flex-end !important;
    margin-top: 20px !important;
}

/* Modal backdrop */
.modal-backdrop {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    background: rgba(0,0,0,0.6) !important;
    z-index: 9999 !important;
}

/* ===== SCROLLBAR ===== */
::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}

::-webkit-scrollbar-track {
    background: #1D1B21;
}

::-webkit-scrollbar-thumb {
    background: #3F3D47;
    border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
    background: #52525B;
}

/* ===== ROW ALIGNMENT ===== */
.gr-row {
    gap: 12px !important;
    align-items: flex-end !important;
}

/* ===== FORMS & GROUPS ===== */
.gr-group {
    background: transparent !important;
    border: none !important;
    padding: 0 !important;
}

.gr-form {
    background: transparent !important;
    border: none !important;
    gap: 16px !important;
}

.gr-block.padded {
    padding: 0 !important;
}

/* ===== GENERATE BUTTON ===== */
.generate-btn {
    width: 100% !important;
    padding: 16px 24px !important;
    font-size: 1rem !important;
    margin-top: 8px !important;
}

/* ===== DIVIDER ===== */
hr {
    border: none !important;
    border-top: 1px solid #3F3D47 !important;
    margin: 20px 0 !important;
}

/* Hide Gradio footer and extra elements */
footer, .footer, .gr-footer { display: none !important; }
.show-api { display: none !important; }
"""


# ============================================
# BUILD UI
# ============================================

with gr.Blocks(css=css, title="TrainBot") as demo:
    
    with gr.Row(elem_classes=["main-row"]):
        
        # ══════════════════════════════════════════════════
        # SIDEBAR
        # ══════════════════════════════════════════════════
        with gr.Column(scale=1, min_width=260, elem_classes=["sidebar"]):
            
            gr.HTML("<div class='sidebar-title'>🎓 TrainBot</div>")
            gr.HTML("<div class='sidebar-subtitle'>AI Course Generator</div>")
            
            gr.Markdown("---")
            
            gr.Markdown("### Sources")
            
            sources_display = gr.Textbox(
                value="No files uploaded yet",
                show_label=False,
                interactive=False,
                lines=5,
                max_lines=8,
                elem_classes=["source-box"]
            )
            
            source_count = gr.Markdown("No files")
            
            file_selector = gr.CheckboxGroup(
                choices=[],
                label="",
                value=[]
            )
            
            gr.Markdown("---")
            
            gr.Markdown("### How to Use")
            gr.Markdown("""
**1. Upload** your documents

**2. Explore** with chat & voice

**3. Generate** courses & quizzes
            """)
            
            gr.Markdown("---")
            gr.HTML("<div style='color: #52525B; font-size: 0.75rem;'>Powered by Gemini & ElevenLabs</div>")
        
        # ══════════════════════════════════════════════════
        # MAIN CONTENT
        # ══════════════════════════════════════════════════
        with gr.Column(scale=4, elem_classes=["main-content"]):
            
            gr.Markdown("# Dashboard")
            gr.Markdown("Transform your documents into training content")
            
            with gr.Tabs():
                
                # ═══════════════════════════════════
                # TAB 1: UPLOAD
                # ═══════════════════════════════════
                with gr.Tab("📁 Upload"):
                    
                    with gr.Column(elem_classes=["content-card"]):
                        gr.Markdown("## Add Your Documents")
                        gr.Markdown("Upload PDFs, presentations, Word docs, or videos")
                        
                        file_input = gr.File(
                            label="Drop files here or click to browse",
                            file_types=[".pdf", ".pptx", ".docx", ".mp4"],
                            type="filepath"
                        )
                        
                        gr.Markdown("---")
                        
                        gr.Markdown("**Add YouTube Video**")
                        with gr.Row():
                            yt_input = gr.Textbox(
                                placeholder="Paste YouTube URL...",
                                show_label=False,
                                scale=4
                            )
                            yt_btn = gr.Button("Add", variant="secondary", scale=1)
                        
                        status_box = gr.Textbox(
                            value="Ready to upload",
                            show_label=False,
                            interactive=False,
                            elem_classes=["status-box"]
                        )
                
                # ═══════════════════════════════════
                # TAB 2: EXPLORE
                # ═══════════════════════════════════
                with gr.Tab("💬 Explore"):
                    
                    with gr.Column(elem_classes=["content-card"]):
                        gr.Markdown("## Explore Your Content")
                        
                        with gr.Tabs(elem_classes=["inner-tabs"]):
                            
                            # Chat
                            with gr.Tab("Chat"):
                                chat_display = gr.Chatbot(
                                    height=260,
                                    show_label=False
                                )
                                with gr.Row():
                                    chat_input = gr.Textbox(
                                        placeholder="Ask anything about your documents...",
                                        show_label=False,
                                        scale=4
                                    )
                                    chat_btn = gr.Button("Send", variant="primary", scale=1)
                            
                            # Voice
                            with gr.Tab("Voice"):
                                gr.Markdown("Record a question and get an audio response")
                                with gr.Row():
                                    audio_input = gr.Audio(
                                        sources=["microphone"],
                                        type="filepath",
                                        label="Record"
                                    )
                                    voice_btn = gr.Button("🎤 Ask", variant="primary")
                                audio_output = gr.Audio(label="Response", type="filepath")
                                voice_output = gr.Textbox(label="Transcript", lines=3)
                            
                            # Summary
                            with gr.Tab("Summary"):
                                summary_type = gr.Dropdown(
                                    choices=["Executive", "Detailed", "Key Points"],
                                    value="Executive",
                                    label="Summary Type"
                                )
                                summary_btn = gr.Button("Generate Summary", variant="primary")
                                summary_output = gr.Textbox(
                                    label="",
                                    lines=10,
                                    show_copy_button=True
                                )
                
                # ═══════════════════════════════════
                # TAB 3: GENERATE
                # ═══════════════════════════════════
                with gr.Tab("🚀 Generate"):
                    
                    with gr.Column(elem_classes=["content-card"]):
                        gr.Markdown("## Create Learning Content")
                        
                        content_type = gr.Dropdown(
                            choices=["Full Course", "Micro Course", "Quiz", "Flashcards"],
                            value="Full Course",
                            label="Content Type"
                        )
                        
                        gr.Markdown("")
                        
                        with gr.Row():
                            gen_title = gr.Textbox(label="Title", value="My Training Course")
                            gen_topic = gr.Textbox(label="Focus Topic", value="Complete Overview")
                        
                        # Course options
                        with gr.Group(visible=True) as course_opts:
                            with gr.Row():
                                course_modules = gr.Dropdown([3,4,5,6,7,8,9,10], value=5, label="Modules")
                                course_level = gr.Dropdown(["Beginner","Intermediate","Advanced"], value="Intermediate", label="Level")
                        
                        # Micro options
                        with gr.Group(visible=False) as micro_opts:
                            with gr.Row():
                                micro_style = gr.Dropdown(["Short Concepts","Executive Overview"], value="Short Concepts", label="Style")
                                micro_modules = gr.Dropdown([3,4,5], value=3, label="Modules")
                        
                        # Quiz options
                        with gr.Group(visible=False) as quiz_opts:
                            with gr.Row():
                                quiz_level = gr.Dropdown(["Basic","Intermediate","Advanced"], value="Intermediate", label="Level")
                                quiz_num = gr.Dropdown([5,6,7,8,9,10], value=5, label="Questions")
                        
                        # Flashcard options
                        with gr.Group(visible=False) as flash_opts:
                            with gr.Row():
                                flash_level = gr.Dropdown(["Basic","Intermediate","Advanced"], value="Intermediate", label="Level")
                                flash_num = gr.Dropdown([5,6,7,8,9,10], value=5, label="Cards")
                        
                        gen_language = gr.Dropdown(
                            ["English","Hindi","Spanish","French","German"],
                            value="English",
                            label="Language"
                        )
                        
                        generate_btn = gr.Button(
                            "🚀 Generate Content",
                            variant="primary",
                            elem_classes=["generate-btn"]
                        )
        
        # ══════════════════════════════════════════════════
        # OUTPUT MODAL
        # ══════════════════════════════════════════════════
        with gr.Group(visible=False, elem_id="output-modal") as output_modal:
            
            gr.Markdown("### ✅ Content Generated Successfully")
            
            gen_output = gr.Textbox(
                label="",
                lines=14,
                max_lines=20,
                show_copy_button=True
            )
            
            with gr.Row():
                close_btn = gr.Button("Close", variant="secondary")
                modal_pdf = gr.DownloadButton("📥 Download PDF", variant="primary")
                regen_btn = gr.Button("🔄 Regenerate", variant="secondary")
    
    # ══════════════════════════════════════════════════
    # EVENT HANDLERS
    # ══════════════════════════════════════════════════
    
    file_input.change(
        upload_file,
        [file_input],
        [sources_display, file_selector, status_box, file_input, source_count]
    )
    
    yt_btn.click(
        add_youtube,
        [yt_input],
        [sources_display, file_selector, status_box, source_count]
    ).then(lambda: "", outputs=yt_input)
    
    file_selector.change(update_selection, [file_selector], [sources_display])
    file_selector.change(delete_file, [file_selector], [sources_display, file_selector, source_count])
    
    chat_btn.click(chat_fn, [chat_input, chat_display], [chat_display, chat_input])
    chat_input.submit(chat_fn, [chat_input, chat_display], [chat_display, chat_input])
    
    voice_btn.click(voice_fn, [audio_input], [audio_output, voice_output])
    summary_btn.click(summary_fn, [summary_type], [summary_output])
    
    def switch_type(mode):
        return (
            gr.update(visible=(mode=="Full Course")),
            gr.update(visible=(mode=="Micro Course")),
            gr.update(visible=(mode=="Quiz")),
            gr.update(visible=(mode=="Flashcards"))
        )
    content_type.change(switch_type, [content_type], [course_opts, micro_opts, quiz_opts, flash_opts])
    
    generate_btn.click(
        generate_content,
        [content_type, gen_title, gen_topic, course_modules, course_level, micro_style, micro_modules, quiz_level, quiz_num, flash_level, flash_num, gen_language],
        [gen_output, modal_pdf, output_modal]
    )
    
    close_btn.click(lambda: gr.update(visible=False), outputs=output_modal)
    
    regen_btn.click(
        generate_content,
        [content_type, gen_title, gen_topic, course_modules, course_level, micro_style, micro_modules, quiz_level, quiz_num, flash_level, flash_num, gen_language],
        [gen_output, modal_pdf, output_modal]
    )


# ============================================
# LAUNCH
# ============================================

if __name__ == "__main__":
    print("=" * 50)
    print("🎓 TrainBot - Dark Theme")
    print("Inspired by Zavvy Dashboard")
    print("=" * 50)
    demo.launch(share=True)
